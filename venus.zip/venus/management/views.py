from django.db.models import Q
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render

# Create your views here.
from management.models import khname, xmname, devname, user, project, fileinfo
from .sigin_token import Token

#装饰器，验证token
def Verifylogin(func):
    '''登陆控制'''
    def deco(request):
        try:
            istoken= request.headers['Authorization']
            '''判定token中的用户名和密码是否正确'''
            data_user = Token().get_username(istoken)
            data_passwd = Token().get_password(istoken)
            result_user = user.objects.filter(username=data_user).first()
            result_passwd = Token().decrypt(result_user.password)
            if result_user:
                if result_passwd == data_passwd:
                    return func(request)
                else:
                    return JsonResponse({'isLogin': 'fail'})
            else:
                return JsonResponse({'isLogin':'fail'})
        except:
            return JsonResponse({'isLogin':'fail'})
    return deco




@Verifylogin
def kh_list(request):
    if request.method=="GET":
        name_dict={}
        name_list=[]
        all = khname.objects.all()
        for i in all:
            name_dict={'name':i.name,'id':i.id}
            name_list.append(name_dict)
            name_dict = {}
    return JsonResponse({'data':name_list})
@Verifylogin
def kh_del(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        name=data['name']
        khname.objects.filter(name=name).delete()
    return JsonResponse({'status':'success'})
@Verifylogin
def kh_add(request):
    if request.method == 'POST':
        data = request.body.decode()
        data = eval(data)
        name = data['name']
        pdresult = khname.objects.filter(name=name)
        print(pdresult)
        if pdresult:
            return JsonResponse({'status': 'reset'})
        else:
            khname.objects.create(
                name=name,
            )
            return JsonResponse({'status': 'success'})

@Verifylogin
def kh_edit(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        name_old=data['old_name']
        name=data['name']
        pdresult = khname.objects.filter(name=name)
        if pdresult:
            return JsonResponse({'status': 'reset'})
        else:
            khname.objects.filter(name=name_old).update(
                name=name)
            return JsonResponse({'status':'success'})

@Verifylogin
def kh_search(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        name=data['name']
    q = Q(Q(name__contains=name))
    ret = khname.objects.filter(q)
    result_list=[]
    result={}
    for i in ret:
        result['name']=i.name
        result_list.append(result)
        result = {}
    return JsonResponse({"result":result_list})

@Verifylogin
def xm_list(request):
    if request.method=="GET":
        name_dict={}
        name_list=[]
        all = xmname.objects.all()
        for i in all:
            name_dict={'name':i.name,'id':i.id}
            name_list.append(name_dict)
            name_dict = {}
    return JsonResponse({'data':name_list})

@Verifylogin
def xm_del(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        name=data['name']
        xmname.objects.filter(name=name).delete()
    return JsonResponse({'status':'success'})

@Verifylogin
def xm_add(request):
    if request.method == 'POST':
        data = request.body.decode()
        data = eval(data)
        name = data['name']
        pdresult = xmname.objects.filter(name=name)
        if pdresult:
            return JsonResponse({'status': 'reset'})
        else:
            xmname.objects.create(
                name=name,
            )
            return JsonResponse({'status': 'success'})

@Verifylogin
def xm_edit(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        name_old=data['old_name']
        name=data['name']
        pdresult = xmname.objects.filter(name=name)
        if pdresult:
            return JsonResponse({'status': 'reset'})
        else:
            xmname.objects.filter(name=name_old).update(
                name=name)
            return JsonResponse({'status':'success'})

@Verifylogin
def xm_search(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        name=data['name']
    q = Q(Q(name__contains=name))
    ret = xmname.objects.filter(q)
    result_list=[]
    result={}
    for i in ret:
        result['name']=i.name
        result_list.append(result)
        result = {}
    return JsonResponse({"result":result_list})

@Verifylogin
def dev_list(request):
    if request.method == "GET":
        name_dict = {}
        name_list = []
        all = devname.objects.all()
        for i in all:
            name_dict = {'name': i.name, 'id': i.id}
            name_list.append(name_dict)
            name_dict = {}
    return JsonResponse({'data': name_list})

@Verifylogin
def dev_del(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        name=data['name']
        devname.objects.filter(name=name).delete()
    return JsonResponse({'status':'success'})

@Verifylogin
def dev_add(request):
    if request.method == 'POST':
        data = request.body.decode()
        data = eval(data)
        name = data['name']
        pdresult = devname.objects.filter(name=name)
        if pdresult:
            return JsonResponse({'status': 'reset'})
        else:
            devname.objects.create(
                name=name,
            )
            return JsonResponse({'status': 'success'})

@Verifylogin
def dev_edit(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        name_old=data['old_name']
        name=data['name']
        pdresult = devname.objects.filter(name=name)
        if pdresult:
            return JsonResponse({'status': 'reset'})
        else:
            devname.objects.filter(name=name_old).update(
                name=name)
            return JsonResponse({'status':'success'})

@Verifylogin
def dev_search(request):
    if request.method == 'POST':
        data = request.body.decode()
        data = eval(data)
        name = data['name']
    q = Q(Q(name__contains=name))
    ret = devname.objects.filter(q)
    result_list = []
    result = {}
    for i in ret:
        result['name'] = i.name
        result_list.append(result)
        result = {}
    return JsonResponse({"result": result_list})


def test(request):
    from .sigin_token import Token
    token=Token()
    ts=token.create_token('nols','xiaoxiao520')
    print(ts)
    username= token.get_username(ts)
    print(username)
    hr = HttpResponse(1)
    hr['set-cookie']='token={}'.format(ts)
    passwd = token.encrypt('xiaoxiao520')
    print(passwd)
    print(Token().decrypt('SW5ocFlXOTRhV0Z2TlRJd0lnOjFuUnhNejowMzB1VlJzY3BQYnNkdXZsWmNOblJkLXpuX00'))
    return hr


def login(request):
    if request.method == 'POST':
        data = request.body.decode()
        data=eval(data)
        username = data['name']
        password = data['password']
        if user.objects.filter(username=username,).first():
            data_passwd = user.objects.filter(username=username).first()
            role = data_passwd.role
            data_passwd = Token().decrypt(data_passwd.password)
            if password == data_passwd:
                token_user = Token().create_token(username,password)
                resp = JsonResponse({'status':'success','token':token_user,'user':username,'role':role})
                return resp
            else:
                return  JsonResponse({'status':'fail'})
        else:
            return JsonResponse({'status': 'fail'})

@Verifylogin
def user_add(request):
    if request.method == 'POST':
        data = request.body.decode()
        data = eval(data)
        print(data)
        name = data['name']
        password = data['password']
        bz=data['bz']
        role = data['role']
        istoken = request.headers['Authorization']
        token_user = Token().get_username(istoken)
        role_number = user.objects.filter(username=token_user).first().role
        print(role_number)
        encrypt_password = Token().encrypt(password)
        pdresult = user.objects.filter(username=name)
        if pdresult:
            return JsonResponse({'status': 'reset'})
        if role_number == '超级管理员':
            user.objects.create(
                username=name,
                password=encrypt_password,
                name=bz,
                role =role,
            )
            return JsonResponse({'status': 'success'})
        else:
            return JsonResponse({'status': 'fail'})




@Verifylogin
def user_list(request):
    if request.method == "GET":
        name_dict = {}
        name_list = []
        all = user.objects.all()
        for i in all:
            name_dict = {'name': i.username, 'id': i.id,'bz':i.name,'role':i.role}
            name_list.append(name_dict)
            name_dict = {}
    return JsonResponse({'data': name_list})

@Verifylogin
def user_del(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        name = data['name']
        istoken = request.headers['Authorization']
        token_user = Token().get_username(istoken)
        role_number = user.objects.filter(username=token_user).first().role
        if token_user != 'admin':
            return JsonResponse({'status': 'fail_noadmin'})
        elif name == 'admin':
            return JsonResponse({'status': 'fail_admin'})
        elif role_number =='超级管理员':
            user.objects.filter(username=name).delete()
            return JsonResponse({'status': 'success'})
        else:
            return JsonResponse({'status':'fail'})

@Verifylogin
def user_edit(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        print(data)
        name = data['name']
        bz = data['bz']
        password = data['password']
        role=data['role']
        istoken = request.headers['Authorization']
        token_user = Token().get_username(istoken)
        role_number = user.objects.filter(username=token_user).first().role
        if role_number == '超级管理员':
            user.objects.filter(username=name).update(
                password = Token().encrypt(password),
                name = bz,
                role=role,
                )
            return JsonResponse({'status': 'success'})
        elif token_user == name:
            user.objects.filter(username=name).update(
                password=Token().encrypt(password),
                name=bz,
            )
            return JsonResponse({'status':'success'})
        else:
            return JsonResponse({'status': 'fail'})

@Verifylogin
def user_search(request):
    if request.method == 'POST':
        data = request.body.decode()
        data = eval(data)
        name = data['name']
    q = Q(Q(username__contains=name)|Q(name__contains=name))

    ret = user.objects.filter(q)
    result_list = []
    result = {}
    for i in ret:
        result['name'] = i.username
        result['bz'] = i.name
        result['role'] = i.role
        result_list.append(result)
        result = {}
    return JsonResponse({"result": result_list})

@Verifylogin
def edit_user(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        name = data['name']
        password = data['password']
        istoken = request.headers['Authorization']
        token_user = Token().get_username(istoken)
        if token_user == name:
            user.objects.filter(username=token_user).update(
                password = Token().encrypt(password),
                )
            return JsonResponse({'status': 'success'})
        else:
            return JsonResponse({'status': 'fail'})

@Verifylogin
def task_list(request):
    if request.method == "GET":
        name_dict = {}
        name_list = []
        file_list =[]
        file_dict = {}
        all = project.objects.all()
        for i in all:
            file_all = fileinfo.objects.filter(uuid=i.uuid)
            name_dict = {'id': i.id, 'xmname': i.xmname, 'khname': i.khname, 'xsname': i.xsname, 'jsname': i.jsname,'xmjingdu':i.xmjingdu,
                         'xmdesc':i.xmdesc,'time':i.time}
            if file_all:
                for item in file_all:
                    file_dict = {'uid':item.id,'name':item.finename,'status':'done','url':item.filepath}
                    file_list.append(file_dict)
                    file_dict = {}
                name_dict['file'] = file_list
                name_list.append(name_dict)
                name_dict = {}
                file_list =[]
            else:
                name_dict['file'] = None
                name_list.append(name_dict)
                name_dict = {}
                file_list = []
        return JsonResponse({'data': name_list})

@Verifylogin
def biaodan_list(request):
    xm = []
    kh = []
    username = []
    xs= []
    xmname_all = xmname.objects.all()
    khname_all = khname.objects.all()
    username_all = user.objects.all()
    xsname_all = devname.objects.all()
    for i in xmname_all:
        xm.append(i.name)
    for i in khname_all:
        kh.append(i.name)
    for i in username_all:
        username.append(i.name)
    for i in xsname_all:
        xs.append(i.name)
    return JsonResponse({'xmname':xm,'khname':kh,'username':username,'xsname':xs})

@Verifylogin
def upload(request):
    from venus.settings import FILE_PATH
    if request.method=='POST':
        fileuuid = request.POST['fileid']
        file = request.FILES.get('file',None)
        if not file:
            pass
        else:
            try:
                file_name = file.name
                path =FILE_PATH + '/' +  fileuuid+'_'+file_name
                #唯一名称
                with open(path,'ab+') as f:
                    for chunk in file.chunks():
                        f.write(chunk)
                #先判断数据库是否有记录存储，同文件
                istrue = fileinfo.objects.filter(uuid=fileuuid,finename=file_name).first()
                if istrue:
                    return JsonResponse({'status': 'istrue'})
                else:
                    fileinfo.objects.create(
                        uuid=fileuuid,
                        filepath=path,
                        finename=file_name,
                    )
                    return JsonResponse({'status':'done'})

            except Exception as e:
                print(e)
                return JsonResponse({'status':'error'})

@Verifylogin
def task_add(request):
    if request.method=='POST':
        try:
            data = request.body.decode()
            data = eval(data)
            print(data)
            project.objects.create(
                uuid=data['xmuuid']['fileid'],
                xmname=data['xmname'],
                khname=data['khname'],
                xsname = data['xsname'],
                jsname = data['jsname'],
                time = data['xmdate'],
                xmjingdu = data['xmjingdu'],
                xmdesc= data['xmdesc'],
            )
            return JsonResponse({'status': 'success'})
        except Exception as e:
            print(e)
            return JsonResponse({'status': 'fail'})

@Verifylogin
def task_del(request):
    if request.method=='POST':
        data = request.body.decode()
        data = eval(data)
        id = data['id']
        istoken = request.headers['Authorization']
        token_user = Token().get_username(istoken)
        role_number = user.objects.filter(username=token_user).first().role
        if role_number =='超级管理员':
            project.objects.filter(id=id).delete()
            return JsonResponse({'status': 'success'})
        else:
            return JsonResponse({'status':'fail'})

    return None

@Verifylogin
def task_search(request):
    if request.method == "POST":
        data = request.body.decode()
        data = eval(data)
        task_name = data['name']
        q = Q(Q(xmname__contains=task_name) | Q(khname__contains=task_name)| Q(xsname__contains=task_name)| Q(jsname__contains=task_name)| Q(xmdesc__contains=task_name))
        name_dict = {}
        name_list = []
        file_list =[]
        file_dict = {}
        all = project.objects.filter(q)
        for i in all:
            file_all = fileinfo.objects.filter(uuid=i.uuid)
            name_dict = {'id': i.id, 'xmname': i.xmname, 'khname': i.khname, 'xsname': i.xsname, 'jsname': i.jsname,'xmjingdu':i.xmjingdu,
                         'xmdesc':i.xmdesc,'time':i.time}
            if file_all:
                for item in file_all:
                    file_dict = {'uid':item.id,'name':item.finename,'status':'done','url':item.filepath}
                    file_list.append(file_dict)
                    file_dict = {}
                name_dict['file'] = file_list
                name_list.append(name_dict)
                name_dict = {}
                file_list =[]
            else:
                name_dict['file'] = None
                name_list.append(name_dict)
                name_dict = {}
                file_list = []
        return JsonResponse({'data': name_list})

@Verifylogin
def task_edit(request):
    if request.method=='POST':
        try:
            data = request.body.decode()
            data = eval(data)
            print(data)
            project.objects.filter(id=data['id']).update(
                xmname=data['xmname'],
                khname=data['khname'],
                xsname=data['xsname'],
                jsname=data['jsname'],
                time=data['xmdate'],
                xmjingdu=data['xmjingdu'],
                xmdesc=data['xmdesc'],
            )
            return JsonResponse({'status': 'success'})
        except Exception as e:
            print(e)
            return JsonResponse({'status': 'fail'})

@Verifylogin
def task_mylist(request):
    if request.method == "GET":
        #判定用户
        istoken = request.headers['Authorization']
        token_user = Token().get_username(istoken)
        user_token = user.objects.filter(username=token_user).first().name
        name_dict = {}
        name_list = []
        file_list = []
        file_dict = {}
        all = project.objects.filter(jsname=user_token)
        for i in all:
            file_all = fileinfo.objects.filter(uuid=i.uuid)
            name_dict = {'id': i.id, 'xmname': i.xmname, 'khname': i.khname, 'xsname': i.xsname, 'jsname': i.jsname,
                         'xmjingdu': i.xmjingdu,
                         'xmdesc': i.xmdesc, 'time': i.time}
            if file_all:
                for item in file_all:
                    file_dict = {'uid': item.id, 'name': item.finename, 'status': 'done', 'url': item.filepath}
                    file_list.append(file_dict)
                    file_dict = {}
                name_dict['file'] = file_list
                name_list.append(name_dict)
                name_dict = {}
                file_list = []
            else:
                name_dict['file'] = None
                name_list.append(name_dict)
                name_dict = {}
                file_list = []
        return JsonResponse({'data': name_list})

@Verifylogin
def task_mysearch(request):
    if request.method == "POST":
        # 判定用户
        istoken = request.headers['Authorization']
        token_user = Token().get_username(istoken)
        user_token = user.objects.filter(username=token_user).first().name

        data = request.body.decode()
        data = eval(data)
        task_name = data['name']
        q = Q(Q(xmname__contains=task_name,jsname=user_token) | Q(khname__contains=task_name,jsname=user_token)| Q(xsname__contains=task_name,jsname=user_token)| Q(xmdesc__contains=task_name,jsname=user_token))
        name_dict = {}
        name_list = []
        file_list =[]
        file_dict = {}
        all = project.objects.filter(q)
        for i in all:
            file_all = fileinfo.objects.filter(uuid=i.uuid)
            name_dict = {'id': i.id, 'xmname': i.xmname, 'khname': i.khname, 'xsname': i.xsname, 'jsname': i.jsname,'xmjingdu':i.xmjingdu,
                         'xmdesc':i.xmdesc,'time':i.time}
            if file_all:
                for item in file_all:
                    file_dict = {'uid':item.id,'name':item.finename,'status':'done','url':item.filepath}
                    file_list.append(file_dict)
                    file_dict = {}
                name_dict['file'] = file_list
                name_list.append(name_dict)
                name_dict = {}
                file_list =[]
            else:
                name_dict['file'] = None
                name_list.append(name_dict)
                name_dict = {}
                file_list = []
        return JsonResponse({'data': name_list})
