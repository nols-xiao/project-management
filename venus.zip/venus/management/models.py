from django.db import models

# Create your models here.

class khname(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100,null=False)

class xmname(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100,null=False)

class devname(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100,null=False)

class user(models.Model):
    id = models.AutoField(primary_key=True)
    username= models.CharField(max_length=100, null=False)
    password=models.CharField(max_length=100, null=False)
    name = models.CharField(max_length=100, null=False)
    role= models.CharField(max_length=100, null=False)

class project(models.Model):
    id = models.AutoField(primary_key=True)
    uuid = models.CharField(max_length=100, null=False)
    xmname= models.CharField(max_length=100, null=False)
    khname=models.CharField(max_length=100, null=False)
    xsname= models.CharField(max_length=100, null=False)
    jsname= models.CharField(max_length=100, null=False)
    devlist =  models.CharField(max_length=1000)
    devxulie =  models.CharField(max_length=1000)
    dingdan = models.CharField(max_length=100)
    xmjingdu = models.CharField(max_length=100)
    xmdesc = models.CharField(max_length=100)
    file = models.CharField(max_length=100)
    file_path =  models.CharField(max_length=100)
    time  = models.CharField(max_length=100)

class fileinfo(models.Model):
    id = models.AutoField(primary_key=True)
    uuid = models.CharField(max_length=100, null=False)
    filepath = models.CharField(max_length=100, null=False)
    finename = models.CharField(max_length=100, null=False)
