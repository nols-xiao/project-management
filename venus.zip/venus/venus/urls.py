"""venus URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.views.generic import TemplateView

from management import views

urlpatterns = [
    path('api/login/',views.login),
    path('api/khname/list/',views.kh_list),
    path('api/khname/del/',views.kh_del),
    path('api/khname/add/',views.kh_add),
    path('api/khname/edit/',views.kh_edit),
    path('api/khname/search/',views.kh_search),
    path('api/xmname/list/',views.xm_list),
    path('api/xmname/del/',views.xm_del),
    path('api/xmname/add/',views.xm_add),
    path('api/xmname/edit/',views.xm_edit),
    path('api/xmname/search/',views.xm_search),
    path('api/devname/list/',views.dev_list),
    path('api/devname/del/',views.dev_del),
    path('api/devname/add/',views.dev_add),
    path('api/devname/edit/',views.dev_edit),
    path('api/devname/search/',views.dev_search),
    path('api/username/add/', views.user_add),
    path('api/username/list/', views.user_list),
    path('api/username/del/',views.user_del),
    path('api/username/edit/',views.user_edit),
    path('api/username/edit_user/',views.edit_user),
    path('api/username/search/',views.user_search),
    path('api/task/search/',views.task_search),
    path('api/task/mysearch/', views.task_mysearch),
    path('api/task/list/', views.task_list),
    path('api/task/mylist/', views.task_mylist),
    path('api/task/add/',views.task_add),
    path('api/task/del/', views.task_del),
    path('api/task/edit/', views.task_edit),
    path('api/biaodan/list/',views.biaodan_list),
    path('upload/add/',views.upload),
    path('test/', views.test),
    path('', TemplateView.as_view(template_name='index.html')),


    path('admin/', admin.site.urls),
    # path('',TemplateView.as_view(template_name='index.html'))
]
